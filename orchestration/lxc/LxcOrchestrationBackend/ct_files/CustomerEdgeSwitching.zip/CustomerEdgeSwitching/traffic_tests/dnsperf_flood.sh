# For installing dnsperf: https://www.gypthecat.com/how-to-dnsperf-on-ubuntu-14-04-with-installation-and-quick-start
dnsperf -s 10.0.3.111 -d domain_list_file -l 60 -q 10 -Q 10
