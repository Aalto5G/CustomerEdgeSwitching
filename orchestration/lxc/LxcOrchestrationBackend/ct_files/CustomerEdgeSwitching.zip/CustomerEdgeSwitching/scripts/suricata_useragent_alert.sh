#!/bin/bash

echo "Generating Suricata user-agent alert via www.test.gwa.demo"
wget -U "Poller/iH" "http://www.test.gwa.demo/10M"
